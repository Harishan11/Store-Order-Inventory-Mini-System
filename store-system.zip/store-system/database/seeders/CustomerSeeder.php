<?php

namespace Database\Seeders;

use App\Models\Customer;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        $customers = [
            ['Thomas Anderson', 'thomas@example.com'],
            ['Priya Sharma', 'priya@example.com'],
            ['Arun Kumar', 'arun@example.com'],
            ['Meena Iyer', 'meena@example.com'],
            ['Rahul Verma', 'rahul@example.com'],
        ];

        foreach ($customers as [$name, $email]) {
            Customer::updateOrCreate(['email' => $email], ['name' => $name]);
        }

        // A few random customers from the factory (only on first run).
        if (Customer::count() < 8) {
            Customer::factory()->count(3)->create();
        }
    }
}
