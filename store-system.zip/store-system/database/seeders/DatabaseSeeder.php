<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Convenience: `php artisan db:seed` alone is enough to get a working database.
        // Creates the tables first (no-op if they already exist).
        Artisan::call('migrate', ['--force' => true]);

        $this->call([
            ProductSeeder::class,
            CustomerSeeder::class,
        ]);
    }
}
