<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $products = [
            ['Colgate Toothpaste 100g', 'COL-100', 50, 18, 40],
            ['Parle-G Biscuit', 'PAR-G01', 10, 5, 120],
            ['Bread (White, 400g)', 'BRD-400', 40, 5, 4],
            ['Amul Milk 1L', 'MLK-1L', 62, 5, 9],
            ['Eggs (Dozen)', 'EGG-12', 84, 0, 2],
            ['Tata Salt 1kg', 'SLT-1KG', 28, 5, 60],
            ['Aashirvaad Atta 5kg', 'ATA-5KG', 285, 5, 25],
            ['Maggi Noodles 70g', 'MAG-70', 14, 12, 150],
            ['Dettol Soap 75g', 'DET-75', 46, 18, 35],
            ['Surf Excel 1kg', 'SRF-1KG', 135, 18, 18],
            ['Fortune Sunflower Oil 1L', 'OIL-1L', 165, 5, 22],
            ['Coca-Cola 750ml', 'COK-750', 40, 18, 7],
        ];

        foreach ($products as [$name, $code, $price, $tax, $stock]) {
            Product::updateOrCreate(
                ['code' => $code],
                ['name' => $name, 'price' => $price, 'tax_percentage' => $tax, 'stock' => $stock]
            );
        }
    }
}
