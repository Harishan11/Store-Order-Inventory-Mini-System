# Store Order & Inventory Mini-System

Laravel 12 · PHP 8.3 · MySQL · Bootstrap 5

---

## Part 1 — Setup (one time)

**Step 1. Unzip the project**
Unzip `store-system.zip` and open a terminal inside the `store-system` folder.

**Step 2. Create the database**
In MySQL (phpMyAdmin / Workbench / terminal) create an empty database:

```sql
CREATE DATABASE store_system;
```

**Step 3. Check `.env`**
Open `.env` and confirm the database lines match your MySQL login:

```
DB_DATABASE=store_system
DB_USERNAME=root
DB_PASSWORD=
```

**Step 4. Install packages**

```
composer install
```

**Step 5. Create tables and sample data**

```
php artisan db:seed
```

This creates all tables and adds 12 sample products and 8 customers.

**Step 6. Start the app**

```
php artisan serve
```

Open http://127.0.0.1:8000

---

## Part 2 — Email setup (so the customer receives the invoice PDF)

By default `.env` has `MAIL_MAILER=log`: the email is only written to `storage/logs/laravel.log`.

To send real emails, edit `.env`:

```
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=youraddress@gmail.com
MAIL_PASSWORD=your-16-char-app-password
MAIL_FROM_ADDRESS=youraddress@gmail.com
MAIL_FROM_NAME="Store System"
```

Then run `php artisan config:clear` and restart `php artisan serve`.

> Gmail needs 2-step verification turned on and an **App Password** (not your normal password).

---

## Part 3 — Daily usage flow

**Step 1. Add products** — Products → Add product. Enter name, unique code, price, tax %, stock.

**Step 2. Add customers** (optional) — Customers → Add customer. New customers are also created automatically at billing time.

**Step 3. Create an order** — click **New order**.
1. Type or pick the customer email. The name fills in automatically if the customer exists; for a new email, type the name.
2. Click **Add product**, choose a product and quantity. Price, tax and line total appear.
3. Repeat for more products.
4. Enter **Amount given by customer** to see the balance to return and the note/coin breakdown.

**Step 4. Click Generate bill.** The system then:
1. Checks stock for every product (blocks the order if stock is not enough).
2. Calculates subtotal, tax (each product's own tax %) and grand total.
3. Deducts stock and saves the order.
4. Shows the bill page.
5. Emails the invoice PDF to the customer's email address (in the background, after the page loads).

**Step 5. After billing** — on the bill page you can Download PDF, Print, or **Email invoice again**.

**Step 6. Monitor** — Dashboard shows revenue, orders and low-stock products. Orders lists all bills.

---

## Part 4 — API endpoints

| Method | URL | Purpose |
|---|---|---|
| POST | `/api/orders` | Create order: `customer_email`, `customer_name`, `items: [{product_id, quantity}]` |
| GET | `/api/customers/{email}/orders` | Order history of a customer |
| GET | `/api/products/low-stock?threshold=10` | Products below the threshold |
| GET | `/api/products` | All products |

---

## Part 5 — Tests

```
php artisan test
```

Covers order creation, totals, insufficient stock, the last-unit case, validation, history, low stock and the invoice email.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Access denied` / unknown database | Check Step 2 and the `DB_*` values in `.env`, then `php artisan config:clear` |
| Email not received | Check `storage/logs/laravel.log` for "Invoice email failed" and review Part 2 |
| Changed `.env` but nothing happens | `php artisan config:clear`, then restart `php artisan serve` |
| Page looks unstyled | The page loads Bootstrap from a CDN, so it needs internet |