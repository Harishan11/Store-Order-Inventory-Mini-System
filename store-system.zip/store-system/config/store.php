<?php

return [
    // Products with stock BELOW this number are reported as "low stock".
    'low_stock_threshold' => (int) env('LOW_STOCK_THRESHOLD', 10),
    'currency' => '₹',
];
