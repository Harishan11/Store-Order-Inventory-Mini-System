<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

Route::get('/', DashboardController::class)->name('dashboard');
Route::resource('products', ProductController::class)->except('show');
Route::resource('customers', CustomerController::class)->only(['index', 'create', 'store']);
Route::resource('orders', OrderController::class)->only(['index', 'create', 'show']);
Route::get('orders/{order}/invoice', [OrderController::class, 'invoice'])->name('orders.invoice');
Route::post('orders/{order}/resend', [OrderController::class, 'resend'])->name('orders.resend');
