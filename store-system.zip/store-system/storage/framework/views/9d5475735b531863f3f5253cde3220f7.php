<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <div>
        <h1 class="page-title h3">Today at the counter</h1>
        <div class="text-muted">Sales, stock and the latest bills.</div>
    </div>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
</div>

<div class="row g-3 mb-4">
    <?php $__currentLoopData = [
        ['Revenue', '₹'.number_format($stats['revenue'], 2), 'bi-cash-stack'],
        ['Orders', $stats['orders'], 'bi-receipt'],
        ['Products', $stats['products'], 'bi-box-seam'],
        ['Customers', $stats['customers'], 'bi-people'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3">
            <div class="panel stat d-flex align-items-center justify-content-between">
                <div><div class="num"><?php echo e($value); ?></div><div class="lbl"><?php echo e($label); ?></div></div>
                <div class="ico"><i class="bi <?php echo e($icon); ?>"></i></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="panel h-100">
            <div class="panel-head">Recent orders <a class="small fw-semibold" href="<?php echo e(route('orders.index')); ?>">View all</a></div>
            <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('orders.show', $order)); ?>" class="d-flex justify-content-between align-items-center text-decoration-none text-reset px-4 py-3 border-bottom">
                    <div>
                        <div class="fw-bold"><?php echo e($order->order_number); ?></div>
                        <div class="small text-muted"><?php echo e($order->customer->name); ?> · <?php echo e($order->created_at->diffForHumans()); ?></div>
                    </div>
                    <div class="fw-bold">₹<?php echo e(number_format($order->grand_total, 2)); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty">No orders yet. <a href="<?php echo e(route('orders.create')); ?>">Create the first one.</a></div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="panel h-100">
            <div class="panel-head"><span><i class="bi bi-exclamation-triangle-fill text-warning me-1"></i> Running low</span><span class="small text-muted fw-semibold">below <?php echo e(config('store.low_stock_threshold')); ?></span></div>
            <?php $__empty_1 = true; $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex justify-content-between align-items-center px-4 py-3 border-bottom">
                    <div><?php echo e($product->name); ?><div class="small text-muted"><?php echo e($product->code); ?></div></div>
                    <span class="badge-stock stock-low"><?php echo e($product->stock); ?> left</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty">Every product is well stocked.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/dashboard.blade.php ENDPATH**/ ?>