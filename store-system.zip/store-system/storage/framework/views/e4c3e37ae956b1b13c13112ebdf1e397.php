<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Orders</h1>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
</div>
<div class="panel">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th class="text-end">Items</th><th class="text-end">Total</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($order->order_number); ?></td>
                    <td><?php echo e($order->customer->name); ?><div class="small text-muted"><?php echo e($order->customer->email); ?></div></td>
                    <td class="text-muted text-nowrap"><?php echo e($order->created_at->format('d M Y, h:i A')); ?></td>
                    <td class="text-end"><?php echo e($order->items_count); ?></td>
                    <td class="text-end fw-bold">₹<?php echo e(number_format($order->grand_total, 2)); ?></td>
                    <td class="text-end"><a href="<?php echo e(route('orders.show', $order)); ?>" class="btn btn-sm btn-light border">View bill</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="empty">No orders yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($orders->hasPages()): ?><div class="p-3"><?php echo e($orders->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/orders/index.blade.php ENDPATH**/ ?>