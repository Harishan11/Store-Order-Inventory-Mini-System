<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Customers</h1>
    <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add customer</a>
</div>

<div class="panel">
    <div class="panel-head">
        <form method="GET" class="d-flex gap-2 w-100" style="max-width:420px">
            <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search by name or email" aria-label="Search customers">
            <button class="btn btn-light border"><i class="bi bi-search"></i></button>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Name</th><th>Email</th><th class="text-end">Orders</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($customer->name); ?></td>
                    <td class="text-muted"><?php echo e($customer->email); ?></td>
                    <td class="text-end"><?php echo e($customer->orders_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3" class="empty">No customers found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($customers->hasPages()): ?><div class="p-3"><?php echo e($customers->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/customers/index.blade.php ENDPATH**/ ?>