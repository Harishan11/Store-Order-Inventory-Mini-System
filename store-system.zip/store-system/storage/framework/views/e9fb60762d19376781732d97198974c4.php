<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; color:#14211f; line-height:1.55;">
    <h2 style="color:#0f3d3a; margin-bottom:4px;">Thank you for your purchase, <?php echo e($order->customer->name); ?>!</h2>
    <p style="margin-top:0;">Your order <strong><?php echo e($order->order_number); ?></strong> has been placed.</p>
    <table cellpadding="6" style="border-collapse:collapse; font-size:14px;">
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product->name); ?> × <?php echo e($item->quantity); ?></td>
                <td align="right">₹<?php echo e(number_format($item->line_total, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr><td style="border-top:1px solid #ccc;"><strong>Grand total</strong></td><td align="right" style="border-top:1px solid #ccc;"><strong>₹<?php echo e(number_format($order->grand_total, 2)); ?></strong></td></tr>
    </table>
    <p>Your invoice is attached as a PDF.</p>
    <p style="color:#6b7b78; font-size:12px;"><?php echo e(config('app.name')); ?></p>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/emails/order-invoice.blade.php ENDPATH**/ ?>