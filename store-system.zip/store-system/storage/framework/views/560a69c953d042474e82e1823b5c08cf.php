<?php $__env->startSection('title', $order->order_number); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .bill { max-width: 760px; }
    .bill-head { background: var(--pine); color: #fff; border-radius: 14px 14px 0 0; padding: 1.25rem 1.5rem; }
    @media print { .sidebar, .topbar, .no-print { display: none !important; } body { background: #fff; } }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php if(request('placed')): ?>
    <div class="alert alert-success border-0 d-flex gap-2 align-items-center no-print" role="alert">
        <i class="bi bi-envelope-check-fill"></i>
        Order placed. The invoice PDF is on its way to <strong><?php echo e($order->customer->email); ?></strong>.
    </div>
<?php endif; ?>

<div class="d-flex flex-wrap gap-2 mb-3 no-print">
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
    <a href="<?php echo e(route('orders.invoice', $order)); ?>" class="btn btn-primary"><i class="bi bi-file-earmark-pdf me-1"></i> Download PDF</a>
    <form method="POST" action="<?php echo e(route('orders.resend', $order)); ?>"><?php echo csrf_field(); ?>
        <button class="btn btn-light border"><i class="bi bi-envelope me-1"></i> Email invoice again</button>
    </form>
    <button class="btn btn-light border" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print</button>
</div>

<div class="bill panel">
    <div class="bill-head d-flex justify-content-between flex-wrap gap-2">
        <div><div class="h4 fw-bold mb-0">Invoice</div><div class="opacity-75"><?php echo e($order->order_number); ?></div></div>
        <div class="text-md-end opacity-75"><?php echo e($order->created_at->format('d M Y, h:i A')); ?></div>
    </div>
    <div class="panel-body">
        <div class="mb-4"><div class="text-muted small">Billed to</div><div class="fw-bold"><?php echo e($order->customer->name); ?></div><div><?php echo e($order->customer->email); ?></div></div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Product</th><th class="text-end">Qty</th><th class="text-end">Price</th><th class="text-end">Tax</th><th class="text-end">Total</th></tr></thead>
                <tbody>
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->name); ?><div class="small text-muted"><?php echo e($item->product->code); ?></div></td>
                        <td class="text-end"><?php echo e($item->quantity); ?></td>
                        <td class="text-end">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                        <td class="text-end"><?php echo e(rtrim(rtrim(number_format($item->tax_percentage, 2), '0'), '.')); ?>%</td>
                        <td class="text-end fw-semibold">₹<?php echo e(number_format($item->line_total, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="ms-auto" style="max-width:320px">
            <div class="d-flex justify-content-between py-1"><span class="text-muted">Subtotal</span><span>₹<?php echo e(number_format($order->subtotal, 2)); ?></span></div>
            <div class="d-flex justify-content-between py-1"><span class="text-muted">Tax</span><span>₹<?php echo e(number_format($order->tax_total, 2)); ?></span></div>
            <div class="d-flex justify-content-between py-2 mt-1 border-top fs-5 fw-bold"><span>Grand total</span><span>₹<?php echo e(number_format($order->grand_total, 2)); ?></span></div>
            <?php if($order->amount_given !== null): ?>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Amount given</span><span>₹<?php echo e(number_format($order->amount_given, 2)); ?></span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Change returned</span><span>₹<?php echo e(number_format($order->change_returned, 2)); ?></span></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/orders/show.blade.php ENDPATH**/ ?>