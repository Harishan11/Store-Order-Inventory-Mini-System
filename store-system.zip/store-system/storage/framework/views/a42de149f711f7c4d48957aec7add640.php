<?php $__env->startSection('title', 'Add product'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="page-title h3 mb-4">Add product</h1>
<div class="panel" style="max-width:820px"><div class="panel-body">
    <form method="POST" action="<?php echo e(route('products.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('products._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/products/create.blade.php ENDPATH**/ ?>