<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Products</h1>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add product</a>
</div>

<div class="panel">
    <div class="panel-head">
        <form method="GET" class="d-flex gap-2 w-100" style="max-width:420px">
            <input type="search" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search by name or code" aria-label="Search products">
            <button class="btn btn-light border"><i class="bi bi-search"></i></button>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Product</th><th>Code</th><th class="text-end">Price</th><th class="text-end">Tax</th><th class="text-end">Stock</th><th></th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($product->name); ?></td>
                    <td class="text-muted"><?php echo e($product->code); ?></td>
                    <td class="text-end">₹<?php echo e(number_format($product->price, 2)); ?></td>
                    <td class="text-end"><?php echo e(rtrim(rtrim(number_format($product->tax_percentage, 2), '0'), '.')); ?>%</td>
                    <td class="text-end">
                        <span class="badge-stock <?php echo e($product->stock < config('store.low_stock_threshold') ? 'stock-low' : 'stock-ok'); ?>"><?php echo e($product->stock); ?></span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-light border" aria-label="Edit <?php echo e($product->name); ?>"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" class="d-inline" onsubmit="return confirm('Delete <?php echo e(addslashes($product->name)); ?>?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-light border text-danger" aria-label="Delete <?php echo e($product->name); ?>"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="empty">No products found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($products->hasPages()): ?><div class="p-3"><?php echo e($products->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/products/index.blade.php ENDPATH**/ ?>