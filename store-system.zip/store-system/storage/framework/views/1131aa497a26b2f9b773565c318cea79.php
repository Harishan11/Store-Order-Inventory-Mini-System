<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice <?php echo e($order->order_number); ?></title>
<style>
    @page { margin: 36px 40px; }
    body { font-family: 'DejaVu Sans', sans-serif; font-size: 11px; color: #14211f; }
    .head { background: #0f3d3a; color: #fff; padding: 18px 22px; }
    .head h1 { margin: 0; font-size: 20px; }
    .head .sub { color: #b6d0cb; margin-top: 3px; }
    table { width: 100%; border-collapse: collapse; }
    .meta td { padding: 14px 0; vertical-align: top; }
    .label { color: #6b7b78; font-size: 10px; }
    .items th { text-align: left; background: #eef3f1; padding: 8px; border-bottom: 1px solid #cfd9d6; font-size: 10px; }
    .items td { padding: 8px; border-bottom: 1px solid #e6ecea; }
    .r { text-align: right; }
    .totals { width: 55%; margin-left: 45%; margin-top: 14px; }
    .totals td { padding: 5px 8px; }
    .grand td { border-top: 2px solid #0f3d3a; font-size: 14px; font-weight: bold; padding-top: 8px; }
    .foot { margin-top: 40px; color: #6b7b78; text-align: center; font-size: 10px; }
</style>
</head>
<body>
    <div class="head">
        <h1>INVOICE</h1>
        <div class="sub"><?php echo e(config('app.name')); ?></div>
    </div>

    <table class="meta">
        <tr>
            <td>
                <div class="label">Billed to</div>
                <strong><?php echo e($order->customer->name); ?></strong><br>
                <?php echo e($order->customer->email); ?>

            </td>
            <td class="r">
                <div class="label">Invoice no.</div>
                <strong><?php echo e($order->order_number); ?></strong><br>
                <span class="label">Date</span> <?php echo e($order->created_at->format('d M Y, h:i A')); ?>

            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
        <tr>
            <th>Product</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Tax</th><th class="r">Line total</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product->name); ?><br><span class="label"><?php echo e($item->product->code); ?></span></td>
                <td class="r"><?php echo e($item->quantity); ?></td>
                <td class="r">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td class="r"><?php echo e(rtrim(rtrim(number_format($item->tax_percentage, 2), '0'), '.')); ?>%</td>
                <td class="r">₹<?php echo e(number_format($item->line_total, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table class="totals">
        <tr><td>Subtotal</td><td class="r">₹<?php echo e(number_format($order->subtotal, 2)); ?></td></tr>
        <tr><td>Tax</td><td class="r">₹<?php echo e(number_format($order->tax_total, 2)); ?></td></tr>
        <tr class="grand"><td>Grand total</td><td class="r">₹<?php echo e(number_format($order->grand_total, 2)); ?></td></tr>
        <?php if($order->amount_given !== null): ?>
            <tr><td>Amount given</td><td class="r">₹<?php echo e(number_format($order->amount_given, 2)); ?></td></tr>
            <tr><td>Change returned</td><td class="r">₹<?php echo e(number_format($order->change_returned, 2)); ?></td></tr>
        <?php endif; ?>
    </table>

    <div class="foot">Thank you for shopping with us.</div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\laravel\store-system\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>