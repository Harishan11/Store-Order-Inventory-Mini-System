<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; color:#14211f; line-height:1.55;">
    <h2 style="color:#0f3d3a; margin-bottom:4px;">Thank you for your purchase, {{ $order->customer->name }}!</h2>
    <p style="margin-top:0;">Your order <strong>{{ $order->order_number }}</strong> has been placed.</p>
    <table cellpadding="6" style="border-collapse:collapse; font-size:14px;">
        @foreach ($order->items as $item)
            <tr>
                <td>{{ $item->product->name }} × {{ $item->quantity }}</td>
                <td align="right">₹{{ number_format($item->line_total, 2) }}</td>
            </tr>
        @endforeach
        <tr><td style="border-top:1px solid #ccc;"><strong>Grand total</strong></td><td align="right" style="border-top:1px solid #ccc;"><strong>₹{{ number_format($order->grand_total, 2) }}</strong></td></tr>
    </table>
    <p>Your invoice is attached as a PDF.</p>
    <p style="color:#6b7b78; font-size:12px;">{{ config('app.name') }}</p>
</body>
</html>
