<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice {{ $order->order_number }}</title>
<style>
    @page { margin: 36px 40px; }
    body { font-family: 'DejaVu Sans', sans-serif; font-size: 11px; color: #14211f; }
    .head { background: #0f3d3a; color: #fff; padding: 18px 22px; }
    .head h1 { margin: 0; font-size: 20px; }
    .head .sub { color: #b6d0cb; margin-top: 3px; }
    table { width: 100%; border-collapse: collapse; }
    .meta td { padding: 14px 0; vertical-align: top; }
    .label { color: #6b7b78; font-size: 10px; }
    .items th { text-align: left; background: #eef3f1; padding: 8px; border-bottom: 1px solid #cfd9d6; font-size: 10px; }
    .items td { padding: 8px; border-bottom: 1px solid #e6ecea; }
    .r { text-align: right; }
    .totals { width: 55%; margin-left: 45%; margin-top: 14px; }
    .totals td { padding: 5px 8px; }
    .grand td { border-top: 2px solid #0f3d3a; font-size: 14px; font-weight: bold; padding-top: 8px; }
    .foot { margin-top: 40px; color: #6b7b78; text-align: center; font-size: 10px; }
</style>
</head>
<body>
    <div class="head">
        <h1>INVOICE</h1>
        <div class="sub">{{ config('app.name') }}</div>
    </div>

    <table class="meta">
        <tr>
            <td>
                <div class="label">Billed to</div>
                <strong>{{ $order->customer->name }}</strong><br>
                {{ $order->customer->email }}
            </td>
            <td class="r">
                <div class="label">Invoice no.</div>
                <strong>{{ $order->order_number }}</strong><br>
                <span class="label">Date</span> {{ $order->created_at->format('d M Y, h:i A') }}
            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
        <tr>
            <th>Product</th><th class="r">Qty</th><th class="r">Price</th><th class="r">Tax</th><th class="r">Line total</th>
        </tr>
        </thead>
        <tbody>
        @foreach ($order->items as $item)
            <tr>
                <td>{{ $item->product->name }}<br><span class="label">{{ $item->product->code }}</span></td>
                <td class="r">{{ $item->quantity }}</td>
                <td class="r">₹{{ number_format($item->unit_price, 2) }}</td>
                <td class="r">{{ rtrim(rtrim(number_format($item->tax_percentage, 2), '0'), '.') }}%</td>
                <td class="r">₹{{ number_format($item->line_total, 2) }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <table class="totals">
        <tr><td>Subtotal</td><td class="r">₹{{ number_format($order->subtotal, 2) }}</td></tr>
        <tr><td>Tax</td><td class="r">₹{{ number_format($order->tax_total, 2) }}</td></tr>
        <tr class="grand"><td>Grand total</td><td class="r">₹{{ number_format($order->grand_total, 2) }}</td></tr>
        @if ($order->amount_given !== null)
            <tr><td>Amount given</td><td class="r">₹{{ number_format($order->amount_given, 2) }}</td></tr>
            <tr><td>Change returned</td><td class="r">₹{{ number_format($order->change_returned, 2) }}</td></tr>
        @endif
    </table>

    <div class="foot">Thank you for shopping with us.</div>
</body>
</html>
