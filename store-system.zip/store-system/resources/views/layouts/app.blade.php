<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') · Counter</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --pine: #0f3d3a;
            --pine-2: #17534f;
            --ink: #14211f;
            --muted: #6b7b78;
            --paper: #f2f5f4;
            --line: #dfe6e4;
            --amber: #f2a516;
            --amber-d: #d98f08;
            --coral: #c2410c;
            --bs-body-font-family: 'Manrope', system-ui, sans-serif;
            --bs-body-color: var(--ink);
            --bs-primary: var(--pine);
            --bs-primary-rgb: 15, 61, 58;
            --bs-border-color: var(--line);
        }
        body { background: var(--paper); font-variant-numeric: tabular-nums; }
        a { color: var(--pine-2); }

        /* Sidebar */
        .sidebar { --bs-offcanvas-width: 262px; background-color: var(--pine) !important; color: #cfe3df; } /* Bootstrap makes .offcanvas-lg transparent on desktop */
        @media (min-width: 992px) {
            .sidebar { width: 262px; flex-shrink: 0; position: sticky; top: 0; height: 100vh; }
        }
        .brand { display: flex; align-items: center; gap: .7rem; font-weight: 800; font-size: 1.15rem; color: #fff; letter-spacing: -.01em; }
        .brand-mark { width: 38px; height: 38px; border-radius: 10px; background: var(--amber); color: var(--pine); display: grid; place-items: center; font-size: 1.2rem; }
        .sidebar .nav-link { color: #b6d0cb; display: flex; align-items: center; gap: .75rem; padding: .7rem .9rem; border-radius: 10px; font-weight: 600; }
        .sidebar .nav-link:hover { background: rgba(255,255,255,.07); color: #fff; }
        .sidebar .nav-link.active { background: #fff; color: var(--pine); }
        .sidebar .nav-link .bi { font-size: 1.1rem; }
        .nav-cta { background: var(--amber); color: var(--pine) !important; justify-content: center; font-weight: 800 !important; }
        .nav-cta:hover { background: var(--amber-d) !important; }

        /* Content */
        .topbar { background: #fff; border-bottom: 1px solid var(--line); }
        .page-title { font-weight: 800; letter-spacing: -.02em; margin: 0; }
        .panel { background: #fff; border: 1px solid var(--line); border-radius: 14px; }
        .panel-head { padding: 1rem 1.25rem; border-bottom: 1px solid var(--line); font-weight: 700; display: flex; align-items: center; justify-content: space-between; gap: 1rem; }
        .panel-body { padding: 1.25rem; }
        .stat { padding: 1.1rem 1.25rem; }
        .stat .num { font-size: 1.9rem; font-weight: 800; letter-spacing: -.03em; line-height: 1.1; }
        .stat .lbl { color: var(--muted); font-weight: 600; font-size: .9rem; }
        .stat .ico { width: 42px; height: 42px; border-radius: 12px; display: grid; place-items: center; background: #e5f0ee; color: var(--pine-2); font-size: 1.2rem; }
        .table > :not(caption) > * > * { padding: .8rem 1.25rem; }
        .table thead th { color: var(--muted); font-weight: 700; font-size: .85rem; background: #f8faf9; border-bottom: 1px solid var(--line); }
        .form-label { font-weight: 700; font-size: .9rem; }
        .form-control, .form-select { border-radius: 10px; padding: .6rem .85rem; border-color: #cfd9d6; }
        .form-control:focus, .form-select:focus { border-color: var(--pine-2); box-shadow: 0 0 0 .2rem rgba(23,83,79,.15); }
        .btn { border-radius: 10px; font-weight: 700; padding: .55rem 1.1rem; }
        .btn-primary { --bs-btn-bg: var(--pine); --bs-btn-border-color: var(--pine); --bs-btn-hover-bg: var(--pine-2); --bs-btn-hover-border-color: var(--pine-2); --bs-btn-active-bg: var(--pine-2); --bs-btn-disabled-bg: var(--pine); --bs-btn-disabled-border-color: var(--pine); }
        .btn-amber { background: var(--amber); color: var(--pine); border: 0; }
        .btn-amber:hover { background: var(--amber-d); color: var(--pine); }
        .badge-stock { font-weight: 700; border-radius: 999px; padding: .35em .75em; }
        .stock-low { background: #fdebd9; color: var(--coral); }
        .stock-ok { background: #e1f1ec; color: var(--pine-2); }
        .empty { padding: 2.5rem 1rem; text-align: center; color: var(--muted); }
        .focus-ring:focus-visible, .btn:focus-visible, .nav-link:focus-visible { outline: 3px solid var(--amber); outline-offset: 2px; }
    </style>
    @stack('styles')
</head>
<body>
<div class="d-flex">
    <aside class="sidebar offcanvas-lg offcanvas-start d-flex flex-column p-3" tabindex="-1" id="sidebar" aria-label="Main navigation">
        <div class="d-flex align-items-center justify-content-between mb-4 px-1 pt-1">
            <div class="brand"><span class="brand-mark"><i class="bi bi-basket3-fill"></i></span> Counter</div>
            <button type="button" class="btn-close btn-close-white d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Close"></button>
        </div>
        <nav class="nav flex-column gap-1">
            <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
            <a class="nav-link {{ request()->routeIs('orders.index', 'orders.show') ? 'active' : '' }}" href="{{ route('orders.index') }}"><i class="bi bi-receipt"></i> Orders</a>
            <a class="nav-link {{ request()->routeIs('products.*') ? 'active' : '' }}" href="{{ route('products.index') }}"><i class="bi bi-box-seam-fill"></i> Products</a>
            <a class="nav-link {{ request()->routeIs('customers.*') ? 'active' : '' }}" href="{{ route('customers.index') }}"><i class="bi bi-people-fill"></i> Customers</a>
        </nav>
        <div class="mt-auto">
            <a class="nav-link nav-cta {{ request()->routeIs('orders.create') ? 'active' : '' }}" href="{{ route('orders.create') }}"><i class="bi bi-plus-lg"></i> New order</a>
        </div>
    </aside>

    <div class="flex-grow-1 min-vw-0" style="min-width:0">
        <header class="topbar d-lg-none d-flex align-items-center gap-3 px-3 py-2 sticky-top">
            <button class="btn btn-light border" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-controls="sidebar" aria-label="Open menu"><i class="bi bi-list fs-5"></i></button>
            <div class="brand text-dark"><span class="brand-mark" style="width:32px;height:32px;font-size:1rem"><i class="bi bi-basket3-fill"></i></span> Counter</div>
        </header>

        <main class="p-3 p-md-4 mx-auto" style="max-width: 1280px">
            @if (session('success'))
                <div class="alert alert-success d-flex align-items-center gap-2 border-0" role="alert"><i class="bi bi-check-circle-fill"></i> {{ session('success') }}</div>
            @endif
            @if (session('error'))
                <div class="alert alert-danger d-flex align-items-center gap-2 border-0" role="alert"><i class="bi bi-exclamation-triangle-fill"></i> {{ session('error') }}</div>
            @endif

            @yield('content')
        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@stack('scripts')
</body>
</html>
