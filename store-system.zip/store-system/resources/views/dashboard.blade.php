@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <div>
        <h1 class="page-title h3">Today at the counter</h1>
        <div class="text-muted">Sales, stock and the latest bills.</div>
    </div>
    <a href="{{ route('orders.create') }}" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
</div>

<div class="row g-3 mb-4">
    @foreach ([
        ['Revenue', '₹'.number_format($stats['revenue'], 2), 'bi-cash-stack'],
        ['Orders', $stats['orders'], 'bi-receipt'],
        ['Products', $stats['products'], 'bi-box-seam'],
        ['Customers', $stats['customers'], 'bi-people'],
    ] as [$label, $value, $icon])
        <div class="col-6 col-xl-3">
            <div class="panel stat d-flex align-items-center justify-content-between">
                <div><div class="num">{{ $value }}</div><div class="lbl">{{ $label }}</div></div>
                <div class="ico"><i class="bi {{ $icon }}"></i></div>
            </div>
        </div>
    @endforeach
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="panel h-100">
            <div class="panel-head">Recent orders <a class="small fw-semibold" href="{{ route('orders.index') }}">View all</a></div>
            @forelse ($recentOrders as $order)
                <a href="{{ route('orders.show', $order) }}" class="d-flex justify-content-between align-items-center text-decoration-none text-reset px-4 py-3 border-bottom">
                    <div>
                        <div class="fw-bold">{{ $order->order_number }}</div>
                        <div class="small text-muted">{{ $order->customer->name }} · {{ $order->created_at->diffForHumans() }}</div>
                    </div>
                    <div class="fw-bold">₹{{ number_format($order->grand_total, 2) }}</div>
                </a>
            @empty
                <div class="empty">No orders yet. <a href="{{ route('orders.create') }}">Create the first one.</a></div>
            @endforelse
        </div>
    </div>
    <div class="col-lg-5">
        <div class="panel h-100">
            <div class="panel-head"><span><i class="bi bi-exclamation-triangle-fill text-warning me-1"></i> Running low</span><span class="small text-muted fw-semibold">below {{ config('store.low_stock_threshold') }}</span></div>
            @forelse ($lowStock as $product)
                <div class="d-flex justify-content-between align-items-center px-4 py-3 border-bottom">
                    <div>{{ $product->name }}<div class="small text-muted">{{ $product->code }}</div></div>
                    <span class="badge-stock stock-low">{{ $product->stock }} left</span>
                </div>
            @empty
                <div class="empty">Every product is well stocked.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection
