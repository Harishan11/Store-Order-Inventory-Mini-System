@extends('layouts.app')
@section('title', 'New order')

@push('styles')
<style>
    .line-table td { vertical-align: middle; }
    .totals-box { background: #f4f8f7; border-radius: 12px; padding: 1.1rem 1.25rem; }
    .totals-box .grand { font-size: 1.5rem; font-weight: 800; letter-spacing: -.02em; }
    .change-chip { background: #fff; border: 1px solid var(--line); border-radius: 8px; padding: .15rem .55rem; font-size: .85rem; font-weight: 700; }
    .alert-low { background: #fff8ea; border: 1px solid #f2c46d; border-radius: 14px; }
</style>
@endpush

@section('content')
<h1 class="page-title h3 mb-4">New order</h1>

<div id="formErrors" class="alert alert-danger border-0 d-none" role="alert"></div>

<div class="row g-4">
    <div class="col-xl-8">
        <div class="panel mb-4">
            <div class="panel-head">Customer</div>
            <div class="panel-body row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="customerEmail">Email</label>
                    <input id="customerEmail" type="email" list="customerList" class="form-control" placeholder="Pick an existing customer or type a new email" autocomplete="off">
                    <datalist id="customerList">
                        @foreach ($customers as $c)<option value="{{ $c->email }}">{{ $c->name }}</option>@endforeach
                    </datalist>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="customerName">Name</label>
                    <input id="customerName" type="text" class="form-control" placeholder="Filled in if the email exists">
                    <div class="form-text" id="customerHint"></div>
                </div>
            </div>
        </div>

        <div class="panel">
            <div class="panel-head">Products</div>
            <div class="table-responsive">
                <table class="table line-table mb-0">
                    <thead><tr><th style="min-width:230px">Product</th><th style="width:100px">Qty</th><th class="text-end">Price</th><th class="text-end">Tax</th><th class="text-end">Line total</th><th></th></tr></thead>
                    <tbody id="lineRows"></tbody>
                </table>
            </div>
            <div class="p-3"><button type="button" class="btn btn-light border" id="addRow"><i class="bi bi-plus-lg me-1"></i> Add product</button></div>
        </div>
    </div>

    <div class="col-xl-4">
        @if ($lowStock->isNotEmpty())
            <div class="alert-low p-3 mb-4">
                <div class="fw-bold mb-2" style="color:#9a5b00"><i class="bi bi-exclamation-triangle-fill me-1"></i> Low stock</div>
                <ul class="mb-0 ps-3 small">
                    @foreach ($lowStock as $p)<li>{{ $p->name }} — {{ $p->stock }} {{ \Illuminate\Support\Str::plural('unit', $p->stock) }} left</li>@endforeach
                </ul>
            </div>
        @endif

        <div class="panel">
            <div class="panel-head">Payment</div>
            <div class="panel-body">
                <div class="totals-box mb-3">
                    <div class="d-flex justify-content-between"><span class="text-muted">Subtotal</span><span id="tSubtotal">₹0.00</span></div>
                    <div class="d-flex justify-content-between"><span class="text-muted">Tax</span><span id="tTax">₹0.00</span></div>
                    <div class="d-flex justify-content-between border-top mt-2 pt-2"><span class="fw-bold">Grand total</span><span class="grand" id="tGrand">₹0.00</span></div>
                </div>
                <label class="form-label" for="amountGiven">Amount given by customer</label>
                <input id="amountGiven" type="number" min="0" step="0.01" class="form-control mb-3" placeholder="0.00">
                <div class="d-flex justify-content-between mb-1"><span class="fw-bold">Balance to return</span><span class="fw-bold" id="tBalance">—</span></div>
                <div id="denoms" class="d-flex flex-wrap gap-1 mb-3"></div>
                <button type="button" id="submitBtn" class="btn btn-amber w-100 py-2 fs-6"><i class="bi bi-receipt me-1"></i> Generate bill</button>
                <div class="form-text mt-2"><i class="bi bi-envelope me-1"></i> The invoice PDF is emailed to the customer.</div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
const productsRaw = {{ Illuminate\Support\Js::from(
    $products->map(function ($p) {
        return [
            'id' => $p->id,
            'name' => $p->name,
            'code' => $p->code,
            'price' => (float) $p->price,
            'tax' => (float) $p->tax_percentage,
            'stock' => $p->stock,
        ];
    })->values()
) }};
const products = Array.isArray(productsRaw) ? productsRaw : Object.values(productsRaw || {});
const customersRaw = @json($customers->pluck('name', 'email'));
const customers = Array.isArray(customersRaw) ? {} : (customersRaw || {});
const money = n => '₹' + Number(n).toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2});
const $ = id => document.getElementById(id);
const rowsEl = $('lineRows');
const round2 = n => Math.round((n + Number.EPSILON) * 100) / 100;

function safely(fn) {
    try { fn(); } catch (err) {
        console.error(err);
        const box = $('formErrors');
        box.textContent = 'Page script error: ' + err.message;
        box.classList.remove('d-none');
    }
}

function addRow() {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><select class="form-select product" aria-label="Product">
            <option value="">Select product…</option>
            ${products.map(p => `<option value="${p.id}" ${p.stock < 1 ? 'disabled' : ''}>${p.name} (${p.stock} in stock)</option>`).join('')}
        </select></td>
        <td><input type="number" class="form-control qty" min="1" value="1" aria-label="Quantity"></td>
        <td class="text-end price">—</td>
        <td class="text-end tax">—</td>
        <td class="text-end fw-semibold total">—</td>
        <td class="text-end"><button type="button" class="btn btn-sm btn-light border text-danger remove" aria-label="Remove line"><i class="bi bi-x-lg"></i></button></td>`;
    rowsEl.appendChild(tr);
    recalc();
}

function recalc() {
    let subtotal = 0, tax = 0;
    const chosen = new Set();
    rowsEl.querySelectorAll('tr').forEach(tr => {
        const p = products.find(x => x.id == tr.querySelector('.product').value);
        const qtyEl = tr.querySelector('.qty');
        if (!p) { ['price', 'tax', 'total'].forEach(c => tr.querySelector('.' + c).textContent = '—'); return; }
        chosen.add(String(p.id));
        qtyEl.max = p.stock;
        let qty = Math.max(1, parseInt(qtyEl.value) || 1);
        const lineSub = round2(p.price * qty), lineTax = round2(lineSub * p.tax / 100);
        subtotal += lineSub; tax += lineTax;
        tr.querySelector('.price').textContent = money(p.price);
        tr.querySelector('.tax').textContent = p.tax + '%';
        tr.querySelector('.total').textContent = money(lineSub + lineTax);
    });
    // Prevent picking the same product twice
    rowsEl.querySelectorAll('.product').forEach(sel => {
        sel.querySelectorAll('option[value]').forEach(o => {
            if (o.value) o.hidden = chosen.has(o.value) && sel.value !== o.value;
        });
    });
    subtotal = round2(subtotal); tax = round2(tax);
    const grand = round2(subtotal + tax);
    $('tSubtotal').textContent = money(subtotal);
    $('tTax').textContent = money(tax);
    $('tGrand').textContent = money(grand);

    const given = parseFloat($('amountGiven').value);
    const denoms = $('denoms'); denoms.innerHTML = '';
    if (isNaN(given)) { $('tBalance').textContent = '—'; return; }
    const balance = round2(given - grand);
    if (balance < 0) { $('tBalance').innerHTML = '<span class="text-danger">Short by ' + money(-balance) + '</span>'; return; }
    $('tBalance').textContent = money(balance);
    let rest = Math.floor(balance);
    [500, 200, 100, 50, 20, 10, 5, 2, 1].forEach(d => {
        const n = Math.floor(rest / d); rest -= n * d;
        if (n) denoms.insertAdjacentHTML('beforeend', `<span class="change-chip">${n} × ₹${d}</span>`);
    });
    const paise = round2(balance - Math.floor(balance));
    if (paise > 0) denoms.insertAdjacentHTML('beforeend', `<span class="change-chip">+ ${money(paise)}</span>`);
}

rowsEl.addEventListener('input', recalc);
rowsEl.addEventListener('change', recalc);
rowsEl.addEventListener('click', e => {
    const btn = e.target.closest('.remove');
    if (btn && rowsEl.children.length > 1) { btn.closest('tr').remove(); recalc(); }
});
$('addRow').addEventListener('click', () => safely(addRow));
$('amountGiven').addEventListener('input', recalc);

$('customerEmail').addEventListener('input', e => {
    const email = e.target.value.trim().toLowerCase();
    const known = customers[email];
    const nameEl = $('customerName');
    if (known) { nameEl.value = known; nameEl.disabled = true; $('customerHint').textContent = 'Existing customer'; }
    else { if (nameEl.disabled) nameEl.value = ''; nameEl.disabled = false; $('customerHint').textContent = email ? 'New customer — will be created' : ''; }
});

function showErrors(data) {
    const box = $('formErrors');
    const msgs = data.errors ? Object.values(data.errors).flat() : [data.message || 'Something went wrong.'];
    box.innerHTML = '<ul class="mb-0">' + msgs.map(m => `<li>${m}</li>`).join('') + '</ul>';
    box.classList.remove('d-none');
    window.scrollTo({top: 0, behavior: 'smooth'});
}

$('submitBtn').addEventListener('click', async () => {
    const items = [...rowsEl.querySelectorAll('tr')]
        .map(tr => ({product_id: parseInt(tr.querySelector('.product').value), quantity: parseInt(tr.querySelector('.qty').value)}))
        .filter(i => i.product_id);
    const btn = $('submitBtn');
    $('formErrors').classList.add('d-none');
    btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Generating…';
    try {
        const res = await fetch(@json(url('/api/orders')), {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
            body: JSON.stringify({
                customer_email: $('customerEmail').value,
                customer_name: $('customerName').value || null,
                amount_given: $('amountGiven').value === '' ? null : $('amountGiven').value,
                items,
            }),
        });
        const data = await res.json();
        if (res.ok) { window.location.href = @json(url('/orders')) + '/' + data.data.id + '?placed=1'; return; }
        showErrors(data);
    } catch (err) {
        showErrors({message: 'Could not reach the server. Please try again.'});
    }
    btn.disabled = false; btn.innerHTML = '<i class="bi bi-receipt me-1"></i> Generate bill';
});

safely(addRow);
</script>
@endpush
