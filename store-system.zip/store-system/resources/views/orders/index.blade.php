@extends('layouts.app')
@section('title', 'Orders')

@section('content')
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Orders</h1>
    <a href="{{ route('orders.create') }}" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
</div>
<div class="panel">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Order</th><th>Customer</th><th>Date</th><th class="text-end">Items</th><th class="text-end">Total</th><th></th></tr></thead>
            <tbody>
            @forelse ($orders as $order)
                <tr>
                    <td class="fw-semibold">{{ $order->order_number }}</td>
                    <td>{{ $order->customer->name }}<div class="small text-muted">{{ $order->customer->email }}</div></td>
                    <td class="text-muted text-nowrap">{{ $order->created_at->format('d M Y, h:i A') }}</td>
                    <td class="text-end">{{ $order->items_count }}</td>
                    <td class="text-end fw-bold">₹{{ number_format($order->grand_total, 2) }}</td>
                    <td class="text-end"><a href="{{ route('orders.show', $order) }}" class="btn btn-sm btn-light border">View bill</a></td>
                </tr>
            @empty
                <tr><td colspan="6" class="empty">No orders yet.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if ($orders->hasPages())<div class="p-3">{{ $orders->links() }}</div>@endif
</div>
@endsection
