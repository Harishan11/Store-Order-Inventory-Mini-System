@extends('layouts.app')
@section('title', $order->order_number)

@push('styles')
<style>
    .bill { max-width: 760px; }
    .bill-head { background: var(--pine); color: #fff; border-radius: 14px 14px 0 0; padding: 1.25rem 1.5rem; }
    @media print { .sidebar, .topbar, .no-print { display: none !important; } body { background: #fff; } }
</style>
@endpush

@section('content')
@if (request('placed'))
    <div class="alert alert-success border-0 d-flex gap-2 align-items-center no-print" role="alert">
        <i class="bi bi-envelope-check-fill"></i>
        Order placed. The invoice PDF is on its way to <strong>{{ $order->customer->email }}</strong>.
    </div>
@endif

<div class="d-flex flex-wrap gap-2 mb-3 no-print">
    <a href="{{ route('orders.create') }}" class="btn btn-amber"><i class="bi bi-plus-lg me-1"></i> New order</a>
    <a href="{{ route('orders.invoice', $order) }}" class="btn btn-primary"><i class="bi bi-file-earmark-pdf me-1"></i> Download PDF</a>
    <form method="POST" action="{{ route('orders.resend', $order) }}">@csrf
        <button class="btn btn-light border"><i class="bi bi-envelope me-1"></i> Email invoice again</button>
    </form>
    <button class="btn btn-light border" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print</button>
</div>

<div class="bill panel">
    <div class="bill-head d-flex justify-content-between flex-wrap gap-2">
        <div><div class="h4 fw-bold mb-0">Invoice</div><div class="opacity-75">{{ $order->order_number }}</div></div>
        <div class="text-md-end opacity-75">{{ $order->created_at->format('d M Y, h:i A') }}</div>
    </div>
    <div class="panel-body">
        <div class="mb-4"><div class="text-muted small">Billed to</div><div class="fw-bold">{{ $order->customer->name }}</div><div>{{ $order->customer->email }}</div></div>
        <div class="table-responsive">
            <table class="table align-middle">
                <thead><tr><th>Product</th><th class="text-end">Qty</th><th class="text-end">Price</th><th class="text-end">Tax</th><th class="text-end">Total</th></tr></thead>
                <tbody>
                @foreach ($order->items as $item)
                    <tr>
                        <td>{{ $item->product->name }}<div class="small text-muted">{{ $item->product->code }}</div></td>
                        <td class="text-end">{{ $item->quantity }}</td>
                        <td class="text-end">₹{{ number_format($item->unit_price, 2) }}</td>
                        <td class="text-end">{{ rtrim(rtrim(number_format($item->tax_percentage, 2), '0'), '.') }}%</td>
                        <td class="text-end fw-semibold">₹{{ number_format($item->line_total, 2) }}</td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <div class="ms-auto" style="max-width:320px">
            <div class="d-flex justify-content-between py-1"><span class="text-muted">Subtotal</span><span>₹{{ number_format($order->subtotal, 2) }}</span></div>
            <div class="d-flex justify-content-between py-1"><span class="text-muted">Tax</span><span>₹{{ number_format($order->tax_total, 2) }}</span></div>
            <div class="d-flex justify-content-between py-2 mt-1 border-top fs-5 fw-bold"><span>Grand total</span><span>₹{{ number_format($order->grand_total, 2) }}</span></div>
            @if ($order->amount_given !== null)
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Amount given</span><span>₹{{ number_format($order->amount_given, 2) }}</span></div>
                <div class="d-flex justify-content-between py-1"><span class="text-muted">Change returned</span><span>₹{{ number_format($order->change_returned, 2) }}</span></div>
            @endif
        </div>
    </div>
</div>
@endsection
