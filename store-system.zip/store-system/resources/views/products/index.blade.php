@extends('layouts.app')
@section('title', 'Products')

@section('content')
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Products</h1>
    <a href="{{ route('products.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add product</a>
</div>

<div class="panel">
    <div class="panel-head">
        <form method="GET" class="d-flex gap-2 w-100" style="max-width:420px">
            <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Search by name or code" aria-label="Search products">
            <button class="btn btn-light border"><i class="bi bi-search"></i></button>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Product</th><th>Code</th><th class="text-end">Price</th><th class="text-end">Tax</th><th class="text-end">Stock</th><th></th></tr></thead>
            <tbody>
            @forelse ($products as $product)
                <tr>
                    <td class="fw-semibold">{{ $product->name }}</td>
                    <td class="text-muted">{{ $product->code }}</td>
                    <td class="text-end">₹{{ number_format($product->price, 2) }}</td>
                    <td class="text-end">{{ rtrim(rtrim(number_format($product->tax_percentage, 2), '0'), '.') }}%</td>
                    <td class="text-end">
                        <span class="badge-stock {{ $product->stock < config('store.low_stock_threshold') ? 'stock-low' : 'stock-ok' }}">{{ $product->stock }}</span>
                    </td>
                    <td class="text-end text-nowrap">
                        <a href="{{ route('products.edit', $product) }}" class="btn btn-sm btn-light border" aria-label="Edit {{ $product->name }}"><i class="bi bi-pencil"></i></a>
                        <form method="POST" action="{{ route('products.destroy', $product) }}" class="d-inline" onsubmit="return confirm('Delete {{ addslashes($product->name) }}?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-light border text-danger" aria-label="Delete {{ $product->name }}"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6" class="empty">No products found.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if ($products->hasPages())<div class="p-3">{{ $products->links() }}</div>@endif
</div>
@endsection
