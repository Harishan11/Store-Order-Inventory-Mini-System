@php($p = $product ?? null)
<div class="row g-3">
    <div class="col-md-8">
        <label class="form-label" for="name">Product name</label>
        <input id="name" name="name" value="{{ old('name', $p?->name) }}" class="form-control @error('name') is-invalid @enderror" required maxlength="255">
        @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="code">Unique code</label>
        <input id="code" name="code" value="{{ old('code', $p?->code) }}" class="form-control @error('code') is-invalid @enderror" required maxlength="50">
        @error('code')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="price">Price per unit (₹)</label>
        <input id="price" name="price" type="number" step="0.01" min="0" value="{{ old('price', $p?->price) }}" class="form-control @error('price') is-invalid @enderror" required>
        @error('price')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="tax_percentage">Tax (%)</label>
        <input id="tax_percentage" name="tax_percentage" type="number" step="0.01" min="0" max="100" value="{{ old('tax_percentage', $p?->tax_percentage ?? 18) }}" class="form-control @error('tax_percentage') is-invalid @enderror" required>
        @error('tax_percentage')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
    <div class="col-md-4">
        <label class="form-label" for="stock">Stock on hand</label>
        <input id="stock" name="stock" type="number" step="1" min="0" value="{{ old('stock', $p?->stock ?? 0) }}" class="form-control @error('stock') is-invalid @enderror" required>
        @error('stock')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>
</div>
<div class="d-flex gap-2 mt-4">
    <button class="btn btn-primary">Save product</button>
    <a href="{{ route('products.index') }}" class="btn btn-light border">Cancel</a>
</div>
