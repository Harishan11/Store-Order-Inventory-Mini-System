@extends('layouts.app')
@section('title', 'Edit product')

@section('content')
<h1 class="page-title h3 mb-4">Edit {{ $product->name }}</h1>
<div class="panel" style="max-width:820px"><div class="panel-body">
    <form method="POST" action="{{ route('products.update', $product) }}" novalidate>
        @csrf @method('PUT')
        @include('products._form', ['product' => $product])
    </form>
</div></div>
@endsection
