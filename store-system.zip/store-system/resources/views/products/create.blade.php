@extends('layouts.app')
@section('title', 'Add product')

@section('content')
<h1 class="page-title h3 mb-4">Add product</h1>
<div class="panel" style="max-width:820px"><div class="panel-body">
    <form method="POST" action="{{ route('products.store') }}" novalidate>
        @csrf
        @include('products._form')
    </form>
</div></div>
@endsection
