@extends('layouts.app')
@section('title', 'Add customer')

@section('content')
<h1 class="page-title h3 mb-4">Add customer</h1>
<div class="panel" style="max-width:640px"><div class="panel-body">
    <form method="POST" action="{{ route('customers.store') }}" novalidate>
        @csrf
        <div class="mb-3">
            <label class="form-label" for="name">Customer name</label>
            <input id="name" name="name" value="{{ old('name') }}" class="form-control @error('name') is-invalid @enderror" required maxlength="255">
            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-4">
            <label class="form-label" for="email">Email</label>
            <input id="email" name="email" type="email" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" required maxlength="255">
            @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <button class="btn btn-primary">Save customer</button>
        <a href="{{ route('customers.index') }}" class="btn btn-light border">Cancel</a>
    </form>
</div></div>
@endsection
