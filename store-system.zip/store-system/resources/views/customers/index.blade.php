@extends('layouts.app')
@section('title', 'Customers')

@section('content')
<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
    <h1 class="page-title h3">Customers</h1>
    <a href="{{ route('customers.create') }}" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Add customer</a>
</div>

<div class="panel">
    <div class="panel-head">
        <form method="GET" class="d-flex gap-2 w-100" style="max-width:420px">
            <input type="search" name="q" value="{{ request('q') }}" class="form-control" placeholder="Search by name or email" aria-label="Search customers">
            <button class="btn btn-light border"><i class="bi bi-search"></i></button>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Name</th><th>Email</th><th class="text-end">Orders</th></tr></thead>
            <tbody>
            @forelse ($customers as $customer)
                <tr>
                    <td class="fw-semibold">{{ $customer->name }}</td>
                    <td class="text-muted">{{ $customer->email }}</td>
                    <td class="text-end">{{ $customer->orders_count }}</td>
                </tr>
            @empty
                <tr><td colspan="3" class="empty">No customers found.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if ($customers->hasPages())<div class="p-3">{{ $customers->links() }}</div>@endif
</div>
@endsection
