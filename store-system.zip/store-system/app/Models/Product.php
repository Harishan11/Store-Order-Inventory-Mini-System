<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'code', 'price', 'tax_percentage', 'stock'];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'tax_percentage' => 'decimal:2',
            'stock' => 'integer',
        ];
    }

    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /** Stock strictly below the threshold (defaults to config value). */
    public function scopeLowStock(Builder $query, ?int $threshold = null): Builder
    {
        return $query->where('stock', '<', $threshold ?? config('store.low_stock_threshold'));
    }
}
