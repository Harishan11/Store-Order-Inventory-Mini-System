<?php

namespace App\Jobs;

use App\Mail\OrderInvoiceMail;
use App\Models\Order;
use App\Services\InvoicePdfService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Throwable;

/**
 * Builds the invoice PDF and emails it to the customer.
 * Asynchronous with QUEUE_CONNECTION=database/redis; inline with "sync".
 */
class SendOrderConfirmation implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;

    public function __construct(public Order $order)
    {
    }

    public function handle(InvoicePdfService $pdf): void
    {
        // PDF generation (first run builds the font cache) and SMTP can be slow; PHP's default limit is 30s.
        @set_time_limit(180);

        $order = $this->order->load(['customer', 'items.product']);

        try {
            Mail::to($order->customer->email, $order->customer->name)
                ->send(new OrderInvoiceMail($order, $pdf->render($order)));

            Log::info('Invoice email sent', ['order' => $order->order_number, 'to' => $order->customer->email]);
        } catch (Throwable $e) {
            Log::error('Invoice email failed', ['order' => $order->order_number, 'error' => $e->getMessage()]);

            // On a real queue, rethrow so it is retried. With "sync" the order is already saved,
            // so don't turn a mail problem into an error page for the cashier.
            if (config('queue.default') !== 'sync') {
                throw $e;
            }
        }
    }
}
