<?php

namespace App\Services;

use App\Models\Order;
use Barryvdh\DomPDF\Facade\Pdf;

class InvoicePdfService
{
    public function render(Order $order): string
    {
        $order->loadMissing(['customer', 'items.product']);

        return Pdf::loadView('pdf.invoice', ['order' => $order])
            ->setPaper('a4')
            ->output();
    }
}
