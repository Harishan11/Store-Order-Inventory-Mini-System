<?php

namespace App\Services;

use App\Exceptions\InsufficientStockException;
use App\Jobs\SendOrderConfirmation;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class OrderService
{
    /**
     * Create an order: lock products, validate stock, compute totals, deduct stock.
     *
     * @param array{customer_email:string, customer_name?:?string, amount_given?:mixed, items:array<int,array{product_id:int,quantity:int}>} $data
     */
    public function create(array $data): Order
    {
        $order = DB::transaction(function () use ($data) {
            $lines = $this->mergeLines($data['items']);

            // Row-level locks (FOR UPDATE) in a stable order: concurrent orders for the same
            // product queue up here, and the second one sees the already-reduced stock.
            $products = Product::whereIn('id', array_keys($lines))
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            $customer = Customer::firstOrCreate(
                ['email' => $data['customer_email']],
                ['name' => $data['customer_name'] ?? $data['customer_email']]
            );

            $subtotal = $taxTotal = 0.0;
            $rows = [];

            foreach ($lines as $productId => $quantity) {
                $product = $products[$productId];

                // Atomic guard: only deducts if enough stock remains (second safety net on top of the lock).
                $deducted = Product::whereKey($productId)
                    ->where('stock', '>=', $quantity)
                    ->decrement('stock', $quantity);

                if (! $deducted) {
                    throw new InsufficientStockException($product, $quantity);
                }

                $lineSubtotal = round((float) $product->price * $quantity, 2);
                $lineTax = round($lineSubtotal * (float) $product->tax_percentage / 100, 2);

                $rows[] = [
                    'product_id' => $productId,
                    'quantity' => $quantity,
                    'unit_price' => $product->price,
                    'tax_percentage' => $product->tax_percentage,
                    'line_subtotal' => $lineSubtotal,
                    'line_tax' => $lineTax,
                    'line_total' => round($lineSubtotal + $lineTax, 2),
                ];

                $subtotal += $lineSubtotal;
                $taxTotal += $lineTax;
            }

            $subtotal = round($subtotal, 2);
            $taxTotal = round($taxTotal, 2);
            $grandTotal = round($subtotal + $taxTotal, 2);

            $given = isset($data['amount_given']) && $data['amount_given'] !== ''
                ? round((float) $data['amount_given'], 2)
                : null;

            if ($given !== null && $given < $grandTotal) {
                throw ValidationException::withMessages([
                    'amount_given' => 'Amount given is less than the grand total of ₹'.number_format($grandTotal, 2).'.',
                ]);
            }

            $order = Order::create([
                'order_number' => 'ORD-'.now()->format('Ymd').'-'.strtoupper(Str::random(5)),
                'customer_id' => $customer->id,
                'subtotal' => $subtotal,
                'tax_total' => $taxTotal,
                'grand_total' => $grandTotal,
                'amount_given' => $given,
                'change_returned' => $given !== null ? round($given - $grandTotal, 2) : null,
            ]);

            $order->items()->createMany($rows);

            return $order->load(['customer', 'items.product']);
        });

        // Dispatched only after the DB transaction has committed.
        // On a real queue it is pushed to the worker; with QUEUE_CONNECTION=sync it runs right after
        // the HTTP response is sent, so a slow PDF/SMTP step never blocks (or times out) the cashier's request.
        if (config('queue.default') === 'sync') {
            SendOrderConfirmation::dispatchAfterResponse($order);
        } else {
            SendOrderConfirmation::dispatch($order);
        }

        return $order;
    }

    /** Merge repeated product lines: [[1,2],[1,3]] => [1 => 5]. */
    private function mergeLines(array $items): array
    {
        $lines = [];
        foreach ($items as $item) {
            $id = (int) $item['product_id'];
            $lines[$id] = ($lines[$id] ?? 0) + (int) $item['quantity'];
        }

        return $lines;
    }
}
