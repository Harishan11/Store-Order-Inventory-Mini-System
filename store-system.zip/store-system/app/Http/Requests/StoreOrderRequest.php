<?php

namespace App\Http\Requests;

use App\Models\Customer;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        if (is_string($this->customer_email)) {
            $this->merge(['customer_email' => strtolower(trim($this->customer_email))]);
        }
    }

    public function rules(): array
    {
        $email = $this->input('customer_email');

        return [
            'customer_email' => ['required', 'email:rfc', 'max:255'],
            // Name is only mandatory when the customer does not exist yet.
            'customer_name' => [
                Rule::requiredIf(fn () => ! (is_string($email) && Customer::where('email', $email)->exists())),
                'nullable', 'string', 'max:255',
            ],
            'amount_given' => ['nullable', 'numeric', 'min:0'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'distinct', 'exists:products,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:100000'],
        ];
    }

    public function messages(): array
    {
        return [
            'items.required' => 'Add at least one product to the order.',
            'items.*.product_id.distinct' => 'The same product appears more than once.',
            'items.*.product_id.exists' => 'One of the selected products no longer exists.',
        ];
    }
}
