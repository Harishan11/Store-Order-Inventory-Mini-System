<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Contracts\View\View;

class DashboardController extends Controller
{
    public function __invoke(): View
    {
        return view('dashboard', [
            'stats' => [
                'products' => Product::count(),
                'customers' => Customer::count(),
                'orders' => Order::count(),
                'revenue' => Order::sum('grand_total'),
            ],
            'lowStock' => Product::lowStock()->orderBy('stock')->limit(8)->get(),
            'recentOrders' => Order::with('customer')->latest()->latest('id')->limit(6)->get(),
        ]);
    }
}
