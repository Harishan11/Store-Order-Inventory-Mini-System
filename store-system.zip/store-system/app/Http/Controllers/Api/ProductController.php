<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /** GET /api/products */
    public function index(): JsonResponse
    {
        return response()->json([
            'data' => Product::orderBy('name')->get(['id', 'name', 'code', 'price', 'tax_percentage', 'stock']),
        ]);
    }

    /** GET /api/products/low-stock?threshold=10 */
    public function lowStock(Request $request): JsonResponse
    {
        $data = $request->validate(['threshold' => ['nullable', 'integer', 'min:1', 'max:1000000']]);
        $threshold = (int) ($data['threshold'] ?? config('store.low_stock_threshold'));

        return response()->json([
            'threshold' => $threshold,
            'data' => Product::lowStock($threshold)->orderBy('stock')->get(['id', 'name', 'code', 'stock']),
        ]);
    }
}
