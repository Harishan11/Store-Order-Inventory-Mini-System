<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Models\Customer;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\Validator;

class CustomerOrderController extends Controller
{
    /** GET /api/customers/{email}/orders */
    public function index(string $email): AnonymousResourceCollection
    {
        $email = strtolower(trim($email));
        Validator::make(['email' => $email], ['email' => ['required', 'email:rfc']])->validate();

        $customer = Customer::where('email', $email)->firstOrFail();

        return OrderResource::collection(
            $customer->orders()->with(['customer', 'items.product'])->latest()->latest('id')->paginate(15)
        );
    }
}
