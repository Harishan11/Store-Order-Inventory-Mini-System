<?php

namespace App\Http\Controllers;

use App\Jobs\SendOrderConfirmation;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use App\Services\InvoicePdfService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;

class OrderController extends Controller
{
    public function index(): View
    {
        $orders = Order::with('customer')->withCount('items')->latest()->latest('id')->paginate(12);

        return view('orders.index', compact('orders'));
    }

    /** The order form posts to the JSON API (POST /api/orders). */
    public function create(): View
    {
        return view('orders.create', [
            'products' => Product::orderBy('name')->get(['id', 'name', 'code', 'price', 'tax_percentage', 'stock']),
            'customers' => Customer::orderBy('name')->get(['name', 'email']),
            'lowStock' => Product::lowStock()->orderBy('stock')->limit(6)->get(['id', 'name', 'stock']),
        ]);
    }

    public function show(Order $order): View
    {
        $order->load(['customer', 'items.product']);

        return view('orders.show', compact('order'));
    }

    /** Download the invoice PDF. */
    public function invoice(Order $order, InvoicePdfService $pdf): Response
    {
        return response($pdf->render($order), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="invoice-'.$order->order_number.'.pdf"',
        ]);
    }

    /** Email the invoice PDF to the customer again. */
    public function resend(Order $order): RedirectResponse
    {
        config('queue.default') === 'sync'
            ? SendOrderConfirmation::dispatchAfterResponse($order)
            : SendOrderConfirmation::dispatch($order);

        return back()->with('success', 'Invoice sent to '.$order->customer->email.'.');
    }
}
