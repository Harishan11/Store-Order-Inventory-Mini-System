<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

class OrderInvoiceMail extends Mailable
{
    /** @param string $pdf Raw PDF bytes of the invoice. */
    public function __construct(public Order $order, public string $pdf)
    {
    }

    public function envelope(): Envelope
    {
        return new Envelope(subject: "Your invoice {$this->order->order_number}");
    }

    public function content(): Content
    {
        return new Content(view: 'emails.order-invoice');
    }

    /** @return array<int, Attachment> */
    public function attachments(): array
    {
        return [
            Attachment::fromData(fn () => $this->pdf, "invoice-{$this->order->order_number}.pdf")
                ->withMime('application/pdf'),
        ];
    }
}
