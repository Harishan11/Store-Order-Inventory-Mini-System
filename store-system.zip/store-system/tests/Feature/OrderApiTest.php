<?php

namespace Tests\Feature;

use App\Jobs\SendOrderConfirmation;
use App\Mail\OrderInvoiceMail;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Bus;
use Tests\TestCase;

class OrderApiTest extends TestCase
{
    use RefreshDatabase;

    private function payload(array $items, array $extra = []): array
    {
        return array_merge([
            'customer_email' => 'thomas@example.com',
            'customer_name' => 'Thomas',
            'items' => $items,
        ], $extra);
    }

    public function test_it_creates_an_order_computes_totals_and_deducts_stock(): void
    {
        Bus::fake();
        $a = Product::factory()->create(['price' => 100, 'tax_percentage' => 9, 'stock' => 10]);
        $b = Product::factory()->create(['price' => 50, 'tax_percentage' => 18, 'stock' => 5]);

        $response = $this->postJson('/api/orders', $this->payload([
            ['product_id' => $a->id, 'quantity' => 2],
            ['product_id' => $b->id, 'quantity' => 1],
        ], ['amount_given' => 300]));

        $response->assertCreated()
            ->assertJsonPath('data.subtotal', '250.00')
            ->assertJsonPath('data.tax_total', '27.00')     // 18.00 (9% of 200) + 9.00 (18% of 50)
            ->assertJsonPath('data.grand_total', '277.00')
            ->assertJsonPath('data.change_returned', '23.00')
            ->assertJsonCount(2, 'data.items');

        $this->assertSame(8, $a->fresh()->stock);
        $this->assertSame(4, $b->fresh()->stock);
        $this->assertDatabaseHas('customers', ['email' => 'thomas@example.com', 'name' => 'Thomas']);
        Bus::assertDispatchedAfterResponse(SendOrderConfirmation::class, 1);
    }

    public function test_it_rejects_an_order_when_stock_is_insufficient(): void
    {
        Bus::fake();
        $product = Product::factory()->create(['stock' => 1]);

        $this->postJson('/api/orders', $this->payload([
            ['product_id' => $product->id, 'quantity' => 2],
        ]))->assertStatus(422)->assertJsonPath('available', 1);

        $this->assertSame(1, $product->fresh()->stock);
        $this->assertDatabaseCount('orders', 0);
        $this->assertDatabaseCount('customers', 0);   // transaction rolled back
        Bus::assertNothingDispatched();
    }

    public function test_a_failing_line_rolls_back_stock_of_other_lines(): void
    {
        $ok = Product::factory()->create(['stock' => 10]);
        $low = Product::factory()->create(['stock' => 1]);

        $this->postJson('/api/orders', $this->payload([
            ['product_id' => $ok->id, 'quantity' => 3],
            ['product_id' => $low->id, 'quantity' => 5],
        ]))->assertStatus(422);

        $this->assertSame(10, $ok->fresh()->stock);
    }

    public function test_last_unit_can_only_be_sold_once(): void
    {
        // Sequential stand-in for two near-simultaneous requests: row lock + guarded decrement
        // guarantee the same outcome under real concurrency on MySQL.
        $product = Product::factory()->create(['stock' => 1]);
        $items = [['product_id' => $product->id, 'quantity' => 1]];

        $this->postJson('/api/orders', $this->payload($items))->assertCreated();
        $this->postJson('/api/orders', $this->payload($items, ['customer_email' => 'other@example.com']))->assertStatus(422);

        $this->assertSame(0, $product->fresh()->stock);
        $this->assertSame(1, Order::count());
    }

    public function test_it_uses_existing_customer_without_requiring_a_name(): void
    {
        Bus::fake();
        $customer = Customer::factory()->create(['email' => 'known@example.com']);
        $product = Product::factory()->create(['stock' => 5]);

        $this->postJson('/api/orders', [
            'customer_email' => 'KNOWN@example.com',
            'items' => [['product_id' => $product->id, 'quantity' => 1]],
        ])->assertCreated();

        $this->assertSame(1, $customer->orders()->count());
        $this->assertDatabaseCount('customers', 1);
    }

    public function test_repeated_product_lines_are_merged_before_the_stock_check(): void
    {
        $product = Product::factory()->create(['price' => 10, 'tax_percentage' => 0, 'stock' => 5]);

        // `distinct` validation rejects duplicates at the API edge...
        $this->postJson('/api/orders', $this->payload([
            ['product_id' => $product->id, 'quantity' => 3],
            ['product_id' => $product->id, 'quantity' => 3],
        ]))->assertStatus(422)->assertJsonValidationErrors('items.0.product_id');

        $this->assertSame(5, $product->fresh()->stock);
    }

    public function test_validation_errors(): void
    {
        $this->postJson('/api/orders', [])->assertStatus(422)
            ->assertJsonValidationErrors(['customer_email', 'customer_name', 'items']);

        $this->postJson('/api/orders', $this->payload([['product_id' => 999, 'quantity' => 0]]))
            ->assertStatus(422)
            ->assertJsonValidationErrors(['items.0.product_id', 'items.0.quantity']);
    }

    public function test_amount_given_must_cover_the_total(): void
    {
        $product = Product::factory()->create(['price' => 100, 'tax_percentage' => 0, 'stock' => 5]);

        $this->postJson('/api/orders', $this->payload(
            [['product_id' => $product->id, 'quantity' => 1]],
            ['amount_given' => 50]
        ))->assertStatus(422)->assertJsonValidationErrors('amount_given');

        $this->assertSame(5, $product->fresh()->stock);
    }

    public function test_order_history_by_email(): void
    {
        Bus::fake();
        $product = Product::factory()->create(['stock' => 10]);
        $items = [['product_id' => $product->id, 'quantity' => 1]];

        $this->postJson('/api/orders', $this->payload($items))->assertCreated();
        $this->postJson('/api/orders', $this->payload($items))->assertCreated();
        $this->postJson('/api/orders', $this->payload($items, ['customer_email' => 'else@example.com']))->assertCreated();

        $this->getJson('/api/customers/thomas@example.com/orders')
            ->assertOk()
            ->assertJsonCount(2, 'data')
            ->assertJsonPath('data.0.customer.email', 'thomas@example.com');

        $this->getJson('/api/customers/nobody@example.com/orders')->assertNotFound();
        $this->getJson('/api/customers/not-an-email/orders')->assertStatus(422);
    }

    public function test_low_stock_endpoint_uses_configurable_threshold(): void
    {
        Product::factory()->create(['name' => 'Low', 'stock' => 3]);
        Product::factory()->create(['name' => 'Plenty', 'stock' => 50]);

        config(['store.low_stock_threshold' => 10]);
        $this->getJson('/api/products/low-stock')
            ->assertOk()->assertJsonPath('threshold', 10)->assertJsonCount(1, 'data')->assertJsonPath('data.0.name', 'Low');

        $this->getJson('/api/products/low-stock?threshold=100')->assertJsonCount(2, 'data');
    }

    public function test_confirmation_job_emails_the_invoice_pdf_to_the_customer(): void
    {
        $product = Product::factory()->create(['stock' => 3]);
        Bus::fake();
        $this->postJson('/api/orders', $this->payload([['product_id' => $product->id, 'quantity' => 1]]))->assertCreated();

        Mail::fake();
        app()->call([new SendOrderConfirmation(Order::first()), 'handle']);

        Mail::assertSent(OrderInvoiceMail::class, function (OrderInvoiceMail $mail) {
            return $mail->hasTo('thomas@example.com') && str_starts_with($mail->pdf, '%PDF');
        });
    }
}
